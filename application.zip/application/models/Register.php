<?php

class Register extends ActiveRecord\Model {


}
