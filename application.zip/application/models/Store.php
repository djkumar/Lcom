<?php

class Store extends ActiveRecord\Model {


}
