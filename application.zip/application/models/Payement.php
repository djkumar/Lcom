<?php

class Payement extends ActiveRecord\Model {

}
