<?php

class Stock extends ActiveRecord\Model {


}
