(function() {
  'use strict';

  angular
    .module('minotaur')
    .controller('LoginController', LoginController);

  /** @ngInject */
  function LoginController(currentAuth, Auth, $log, $state, toastr, $http) {
    var vm = this;
console.log(this)
    toastr.success('demo@tattek.sk, pass: minotaur', 'Login default data!', {progressBar: true, timeOut: '15000'});

    vm.currentAuth = currentAuth;

    //redirect if user is logged in
    if (vm.currentAuth) {
      $state.go('dashboard', {}, {reload: true});
    }

    vm.login = function() {
      vm.error = null;
      Auth.$signInWithEmailAndPassword(vm.email, vm.password).then(function(authData) {
          $log.log("Authenticated successfully with payload:", authData);
          $state.go('dashboard', {}, {reload: true});
        }, function(err) {
          vm.err = err;
          toastr.error(vm.err.message, 'Login Failed!');
          $log.log("Login Failed!", err);
        });
    };
  }


    function LoginController_test(currentAuth, Auth, $log, $state, toastr, $http) {
    
    var vm = this;
vm.login = function() { 
  var request = $http({
                method: "post",
                url: "index.php/login_controller/checkuser",
                data: {
                    email: this.email,
                    password: this.password
                },
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }).then(function (data){ 
            //  console.log(data.data);
                if(data.data == "1"){
          $state.go('dashboard', {}, {reload: true});
                }
                else {
          $state.go('dashboard', {}, {reload: true});
                }
            });

};
    //redirect if user is logged in
   /* if (vm.currentAuth) {
      $state.go('dashboard', {}, {reload: true});
    }

    vm.login = function() {
      vm.error = null;
      Auth.$signInWithEmailAndPassword(vm.email, vm.password).then(function(authData) {
          $log.log("Authenticated successfully with payload:", authData);
          $state.go('dashboard', {}, {reload: true});
        }, function(err) {
          vm.err = err;
          toastr.error(vm.err.message, 'Login Failed!');
          $log.log("Login Failed!", err);
        });
    };*/



  }



})();
