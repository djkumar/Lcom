/* global moment:false, firebase: false */
(function() {
  'use strict';

  /* eslint-disable */
  angular
    .module('minotaur')
    .constant('moment', moment)
    .constant('firebase', firebase);
  /*eslint-enable*/

})();
