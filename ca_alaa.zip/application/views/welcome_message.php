
<!doctype html>
<html ng-app="minotaur" ng-class="specialClass">
  <head>
    <meta charset="utf-8">
    <title>My - Admin Dashboard</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">
    <!-- Chrome, Firefox OS, Opera and Vivaldi -->
    <meta name="theme-color" content="#1199d3">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#1199d3">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#1199d3">
    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

    <!-- build:css({.tmp/serve,src}) styles/vendor.css -->
    <!-- bower:css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/angular-toastr/dist/angular-toastr.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/animate.css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/angular-loading-bar/build/loading-bar.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/magnific-popup/dist/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/slick-carousel/slick/slick.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/slick-carousel/slick/slick-theme.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/chosen/chosen.css" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>bower_components/ng-table/dist/ng-table.css" />
    <!-- endbower -->
    <!-- endbuild -->

    <!-- build:css({.tmp/serve,src}) styles/app.css -->
    <!-- inject:css -->
    <link rel="stylesheet" href="app/index.css">
    <!-- endinject -->
    <!-- endbuild -->
  </head>
  <body id="minotaur" class="appWrap {{main.headerStyle}} {{main.primaryColor}}" ng-class="specialClass" ng-controller="MainController as main"><script type='text/javascript' id="__bs_script__">//<![CDATA[
    document.write("<script async src='browser-sync/browser-sync-client.2.9.12.js'><\/script>".replace("HOST", location.hostname));
//]]></script>

    <!--[if lt IE 10]>
      <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <div id="wrap">

      <minotaur-header ng-class="specialClass" ng-if="specialClass !== 'core'"></minotaur-header>

      <div id="additional-header-space" ng-if="specialClass !== 'core'" ng-cloak></div>

      <minotaur-nav ng-class="specialClass" ng-if="specialClass !== 'core'"></minotaur-nav>

      <section id="content" ui-view></section>

      <minotaur-loading></minotaur-loading>

      <!-- <minotaur-customize></minotaur-customize> -->

    </div>

<!--     <script src="https://maps.google.com/maps/api/js?libraries=placeses,visualization,drawing,geometry,places"></script>
 -->
    <!-- build:js(src) scripts/vendor.js -->
    <!-- bower:js -->
    <script src="<?php echo base_url(); ?>bower_components/jquery/dist/jquery.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/lodash/dist/lodash.min.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular/angular.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-animate/angular-animate.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-cookies/angular-cookies.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-touch/angular-touch.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-sanitize/angular-sanitize.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-messages/angular-messages.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-aria/angular-aria.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-resource/angular-resource.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-ui-router/release/angular-ui-router.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-bootstrap/ui-bootstrap-tpls.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-toastr/dist/angular-toastr.tpls.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/moment/moment.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-translate/angular-translate.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-translate-loader-static-files/angular-translate-loader-static-files.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-translate-storage-cookie/angular-translate-storage-cookie.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-translate-storage-local/angular-translate-storage-local.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/jquery-slimscroll/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-loading-bar/build/loading-bar.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-fullscreen/src/angular-fullscreen.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/magnific-popup/dist/jquery.magnific-popup.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/slick-carousel/slick/slick.min.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-slick/dist/slick.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/chart.js/dist/Chart.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-chart.js/dist/angular-chart.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/chosen/chosen.jquery.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-chosen-localytics/dist/angular-chosen.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/ng-file-upload/ng-file-upload.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/bootstrap-filestyle/src/bootstrap-filestyle.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angular-validation-match/dist/angular-validation-match.min.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/ng-table/dist/ng-table.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/firebase/firebase.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/angularfire/dist/angularfire.js"></script>
    <script src="<?php echo base_url(); ?>bower_components/ngAlertify/ngAlertify.js"></script>
    <!-- endbower -->
    <!-- endbuild -->

    <!-- build:js({.tmp/serve,.tmp/partials,src}) scripts/app.js -->
    <!-- inject:js -->
    <script src="app/index.module.js"></script>
    <script src="app/components/partials/rightbar/rightbar.directive.js"></script>
    <script src="app/components/partials/navigation/navigation.directive.js"></script>
    <script src="app/components/partials/header/header.directive.js"></script>
    <script src="app/components/partials/customize/minotaur-customize.directive.js"></script>
    <script src="app/pages/users/users.controller.js"></script>
    <script src="app/pages/signup/signup.controller.js"></script>
    <script src="app/pages/settings/settings.controller.js"></script>
    <script src="app/pages/profile/profile.controller.js"></script>
    <script src="app/pages/products/products.controller.js"></script>
    <script src="app/pages/orders/orders.controller.js"></script>
    <script src="app/pages/login/login.controller.js"></script>
    <script src="app/pages/forgotpass/forgotpass.controller.js"></script>
    <script src="app/pages/dashboard/dashboard.controller.js"></script>
    <script src="app/pages/categories/categories.controller.js"></script>
    <script src="app/components/services/digits.filter.js"></script>
    <script src="app/components/services/auth.factory.js"></script>
    <script src="app/components/directives/vector-map.directive.js"></script>
    <script src="app/components/directives/validate-on-submit.directive.js"></script>
    <script src="app/components/directives/sparkline.directive.js"></script>
    <script src="app/components/directives/slimscroll.directive.js"></script>
    <script src="app/components/directives/native-tabs.directive.js"></script>
    <script src="app/components/directives/mixitup.directive.js"></script>
    <script src="app/components/directives/minotaur-tile-refresh.directive.js"></script>
    <script src="app/components/directives/minotaur-tile-minimize.directive.js"></script>
    <script src="app/components/directives/minotaur-tile-lightbox.directive.js"></script>
    <script src="app/components/directives/minotaur-tile-fullscreen.directive.js"></script>
    <script src="app/components/directives/minotaur-tile-close.directive.js"></script>
    <script src="app/components/directives/minotaur-loading.directive.js"></script>
    <script src="app/components/directives/magnific-popup.directive.js"></script>
    <script src="app/components/directives/leaflet.directive.js"></script>
    <script src="app/components/directives/keypress-escape.directive.js"></script>
    <script src="app/components/directives/input-mask.directive.js"></script>
    <script src="app/components/directives/gaugejs-chart.directive.js"></script>
    <script src="app/components/directives/count-to.directive.js"></script>
    <script src="app/components/directives/clock.directive.js"></script>
    <script src="app/components/directives/bootstrap-filestyle.directive.js"></script>
    <script src="app/components/directives/anchor-scroll.directive.js"></script>
    <script src="app/components/directives/active-toggle.directive.js"></script>
    <script src="app/components/directives/activate-button.directive.js"></script>
    <script src="app/index.run.js"></script>
    <script src="app/index.route.js"></script>
    <script src="app/index.controller.js"></script>
    <script src="app/index.constants.js"></script>
    <script src="app/index.config.js"></script>
    <!-- endinject -->

    <!-- inject:partials -->
    <!-- angular templates will be automatically converted in js and inserted here -->
    <!-- endinject -->
    <!-- endbuild -->

    <script>
      // Initialize Firebase
      var config = {
        apiKey: "AIzaSyCFdhNl2sQuKI0FBiKHf5tdLu2nnLre-7Q",
        authDomain: "minotaur-crud.firebaseapp.com",
        databaseURL: "https://minotaur-crud.firebaseio.com",
        storageBucket: "minotaur-crud.appspot.com",
        messagingSenderId: "886541874643"
      };
      firebase.initializeApp(config);
      var secondaryApp = firebase.initializeApp(config, "Secondary");

      // keeps track of all open firebase connections to be $destroy'ed
      // when logging out. stored as a global variable since config doesn't
      // have $rootscope and needs to be globally accessible
      window.openFirebaseConnections = [];
    </script>

    <script src="https://cdn.rawgit.com/google/code-prettify/master/loader/run_prettify.js?skin=sons-of-obsidian"></script>

  </body>
</html>
