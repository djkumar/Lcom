<?php
defined('BASEPATH') or die('No direct scripts allowed');
class Login_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('login_model');
	}
	public function index(){
		$this->load->view('app/pages/login/login.html');
	}
	public function checkuser(){
		 $request= json_decode(file_get_contents('php://input'), TRUE);
	 $result =	$this->login_model->get_details($request['email'], $request['password']);
 if($result)
      {
         echo $result = '1';
      }else{
         echo $result = '0';
      }
	}
}
?>