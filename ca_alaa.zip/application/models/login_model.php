<?php
class login_model extends CI_Model{
	
	function __construct(){
		parent::__construct();
	}
	public function get_details($email, $pass){

$condition = "user_email LIKE '$email' AND  user_password LIKE md5('$pass')";
$this->db->select('*');
$this->db->from('users');
$this->db->where($condition);
$this->db->limit(1);
  $query = $this->db->get();

if ($query->num_rows() == 1) {
return true;
} else {
return false;
}



	}
}