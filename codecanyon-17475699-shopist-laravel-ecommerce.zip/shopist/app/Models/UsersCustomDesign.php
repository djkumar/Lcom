<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class UsersCustomDesign extends Model
{
  protected $table = 'users_custom_designs';
}
