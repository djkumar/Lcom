<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class Option extends Model
{
   
  protected $table = 'options';
}
