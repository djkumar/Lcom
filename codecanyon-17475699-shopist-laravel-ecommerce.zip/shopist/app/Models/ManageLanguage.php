<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class ManageLanguage extends Model
{
  protected $table = 'manage_languages';
}
