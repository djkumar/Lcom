<?php
namespace shopist\Models;

use Illuminate\Database\Eloquent\Model;

class OrdersItem extends Model
{
   
  protected $table = 'orders_items';
}
