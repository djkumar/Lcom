<footer id="footer" class="footer-wrapper">
  @include( 'frontend-templates.footer.black-crazy.black-crazy' )
</footer>