$(document).ready(function(){
  if($('#footer').length>0){
    $('#footer [data-toggle="tooltip"]').tooltip(); 
  }
});