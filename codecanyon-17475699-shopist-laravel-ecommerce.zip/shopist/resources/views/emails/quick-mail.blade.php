<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
  <div marginheight="0" marginwidth="0">
    <div style="background-color:#f5f5f5;margin:0;padding:70px 0 70px 0;width:100%" dir="ltr">
      <p>{!! $_message !!}</p>
    </div>
  </div>
</body>
</html>